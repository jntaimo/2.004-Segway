# Pinout Cards - Unexpected Maker - ESP32-S3 Boards 
Hires pinout cards for my ESP32-S3 boards  

You can find out more about my ESP32-S3 boards at https://esp32s3.com 

Artwork and content in this folder is (c)2022 Unexpected Maker, all rights reserved.
